import React from 'react'

export default function Header() {
    return (
        <div>
             <h1>My Interview Portal</h1>
            <hr/>
        </div>
    )
}
