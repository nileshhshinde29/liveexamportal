import React from 'react';
import "./Questions.css"
import ReCAPTCHA from "react-google-recaptcha";
import { useNavigate } from 'react-router';

import axios from "axios"


function Login() {
    const navigate= useNavigate()

    const [link, setTokan] = React.useState("")
      const recaptchaRef = React.createRef();
    const [loginInfo, setLoginInfo] = React.useState({

        email: "",
        password: "",
        reCaptchaToken:""



    })

    function setValue(e)
    { 
        const {name, value} = e.target
        setLoginInfo(prv=>({...prv , [name]:value}))

    }

    function fetchApi(pageNo="") {
        axios.get(`http://admin.liveexamcenter.in/api/auth/self`, { headers: { authorization:link  } })
        .then((response) => {
            // setAllData(response.data)
            console.log("success");
            // console.log(response);
            navigate("/" )
          
        })
        .catch((error) =>
            console.log(error)
        
            )

      }
      





    function LoginWithInfo() {
        axios(` https://admin.liveexamcenter.in/api/auth/login`,

            {
                method: 'POST',
                data: loginInfo,

                headers: {

                    "Content-Type": 'application/json'
                }
            })
            .then((response) => {
                // console.log("success")
                console.log(response.data.token);
                // console.log("success")
                setTokan(response.data.token)




            })
            .catch((error) =>
                console.log(error)
            )

           


    }
   
    const onSubmitWithReCAPTCHA = async () => {
        const token = await recaptchaRef.current.executeAsync();
        setLoginInfo(prv=>({...prv, reCaptchaToken:token}))
      
        
    }
    React.useEffect(()=>{
      if(loginInfo.reCaptchaToken!=="")
      {
        LoginWithInfo()
        //  fetchApi()
      }

    },[loginInfo.reCaptchaToken])

    React.useEffect(()=>{
        if(link!=="")
        {
            fetchApi()
        }
    })

    return <div>
        <div11 >
            <form>
                <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Email address</label>
                    <input type="email" class="form-control" id="exampleInputEmail1" name='email' value={loginInfo.email} onChange={(e=>setValue(e))} aria-describedby="emailHelp" />
                    {/* <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div> */}
                </div>
                <div class="mb-3">
                    <label for="exampleInputPassword1" class="form-label">Password</label>
                    <input type="password" class="form-control" name="password" value={loginInfo.password} onChange={(e=>setValue(e))} id="exampleInputPassword1" />
                </div>
                <div class="mb-3 form-check">
                    {/* <input type="checkbox" class="form-check-input" id="exampleCheck1"/> */}
                    {/* <label class="form-check-label" for="exampleCheck1">Check me out</label> */}
                    <ReCAPTCHA
                        ref={recaptchaRef}
                        size="invisible"
                        sitekey="6Ld3COIZAAAAAC3A_RbO1waRz6QhrhdObYOk7b_5"
                        // onChange={onChange}
                    />
                    
                </div>
                <button type="button" onClick={() => onSubmitWithReCAPTCHA()} class="btn btn-primary float-start">Login</button>
            </form>

        </div11>
    </div>;


}

export default Login;
