        import './App.css';
        import  React, { useState } from 'react'
        import Navebar from './Components/Navbar';
        import axios from 'axios'
        import AddQuestion from "./Components/AddQuestion"
        import {BrowserRouter as Router, Switch,Route, Routes, useSearchParams } from 'react-router-dom';
        import Edit from "./Components/Edit"
        import Login from "./Components/Login"
        import { useLocation } from 'react-router-dom';


        import Question from './Components/Questions';

        function App() {
          // const location = useLocation()
          // console.log(location.state)
          const [AllData, setAllData]=React.useState([])
          const [arrayLength, setLength]=React.useState()
          // const [pageNo ,setPageNo]=React.useState(1)
          const [topic , setTopic]=React.useState("")
          const AuthorisationLink="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJfaWQiOiI2MWRlN2Y1Y2U2ZDdkNzdjOGU0ZmI2NDQiLCJfYWN0aXZlT3JnIjoiNjE5Y2U0YThlNTg2ODUxNDYxMGM4ZGE3IiwiaWF0IjoxNjQzNjAxNzk5LCJleHAiOjE2NDM2NDQ5OTl9.2TDOLc7JEzupId4NY8fc0FehTv40ZXYrjhjWFq5QbGo"
          // const [topic , setTopic]=React.useState("")

        function fetchApi(pageNo="") {
          axios.get(`http://admin.liveexamcenter.in/api/questions?page=${pageNo}&limit=&term=&topic=${topic}`, { headers: { authorization: AuthorisationLink  } })
          .then((response) => {
              setAllData(response.data)
            
          })
          .catch((error) =>
              console.log(error)
          
              )

        }
        

        function TopicFunction(topic)
        {
            setTopic(topic)
            console.log(topic)
        }

        React.useEffect(() => {
          fetchApi(1,topic)
        }, [topic])

          // setLength(AllData.result.length)
    const [FullScreen , setFullScreen]=useState(false)

         const FullScreenfunction=(props)=>{
            setFullScreen(props)
         } 





        // console.log(AllData)
          return (
            <Router>
            <div className="App">
              {FullScreen ?"":<Navebar />  } 
            <Routes>  

            <Route path="/" element={ <Question  data={AllData} AuthorisationLink={AuthorisationLink} TopicFunction={TopicFunction} />}/>
            <Route path="/add" element={<AddQuestion  AuthorisationLink={AuthorisationLink} AllData={AllData} FullScreenfunction={FullScreenfunction} />}/>
            <Route path="/edit" element={<Edit  AuthorisationLink={AuthorisationLink} AllData={AllData} FullScreenfunction={FullScreenfunction}/>}/>
            <Route path="/login" element={<Login /> }/>
            </Routes>
            </div>
              
            </Router>
          );
        }

        export default App;


        // <Router>
      //  <Header />
      //  <Routes>        
         
      //   <Route path="/"     element={<ContactList contact={contact} getId={contactRemove}  getId1={ContactView}/>}/>
      //   <Route path="/add"  element={<AddContacts inputs={inputs} />}/>
      //   <Route path="/view" element={<View />}/>
      // {/* <AddContacts inputs={inputs}/> */}
      //   {/* <ContactList contact={contact} getId={contactRemove}/> */}
      //   </Routes>
      // </Router>